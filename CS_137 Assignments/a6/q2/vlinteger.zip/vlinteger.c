#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "vlinteger.h"

struct linteger *vlintegerCreate(void){
    struct linteger *t1 = malloc(sizeof(struct linteger));
    assert(t1);
    t1->arr = NULL;
    t1->length = 0;
    return t1;
}

void vlintegerDestroy(struct linteger *v){
    if(v){
        free(v->arr);
        free(v);
    }
}

void vlintegerRead(struct linteger *t1){
    int num = 0;
    while(scanf("%d", &num) == 1){
        int size = t1->length + 1;
        
        int *temp = malloc(sizeof(int) * size);
        assert(temp);
        for (int i = 0; i < t1->length; i++) {
            temp[i] = t1->arr[i];
        }
        temp[t1->length] = num;
        t1->length++;
        free(t1->arr);
        t1->arr = temp;
        // free(temp);
    }
}


void vlintegerPrint(struct linteger *t1){
    printf("length=%d\n", t1->length);
    for(int i = 0; i < t1->length; i++){
        printf("%d", t1->arr[i]);
    }
    printf("\n");
}


struct linteger *vlintegerAdd(struct linteger *t1, struct linteger *t2){
    int longerLength = 0;

    if (t1->length > t2->length) {
        longerLength = t1->length;
    } else {
        longerLength = t2->length;
    }

    int *temp = malloc(sizeof(int) * longerLength);
    assert(temp);
    struct linteger *final = malloc(sizeof(struct linteger));
    assert(final);
    int tempValue = 0;
    int i = t1->length;
    int j = t2->length;
    int k = longerLength;

    while (i > 0 && j > 0) {
        tempValue += t1->arr[i-1] + t2->arr[j-1];
        temp[k - 1] = tempValue % 10;
        tempValue = tempValue / 10;
        i--;
        j--;
        k--;
    }

    while (i > 0) {
        tempValue += t1->arr[i];
        temp[k - 1] = tempValue % 10;
        tempValue /= 10;
        k--;
        i--;
    }
    while (j > 0) {
        tempValue += t2->arr[j];
        temp[k - 1] = tempValue % 10;
        tempValue /= 10;
        k--;
        j--;
    }

    if(tempValue != 0){
        final->arr = malloc((longerLength + 1) * sizeof(int));
        final->arr[0] = tempValue;
        final->length = longerLength + 1;
        for (int i = 1; i < final->length; i++)
        {
            final->arr[i] = temp[i-1];
        }
        free(temp);
    }
    else{
        final->length = longerLength;
        final->arr = temp;
    }
   
    return final;
}

struct linteger *vlintegerMult(struct linteger *t1, struct linteger *t2){

    int longerLength = t1->length + t2->length;

    int *temp = calloc(longerLength, sizeof(int));
    assert(temp);
    struct linteger *final = malloc(sizeof(struct linteger));
    assert(final);

    for(int i = t1->length - 1; i >= 0; i--){
        for(int j = t2->length - 1; j >= 0; j--){
            temp[i + j + 1] += t1->arr[i] * t2->arr[j];
            temp[i + j] += temp[i + j + 1] / 10;
            temp[i + j + 1] = temp[i + j + 1] % 10;
        }
    }
    
    int k = 0;
    if(temp[0] == 0){
        final->arr = malloc((longerLength - 1) * sizeof(int));
        for(int i = 1; i < longerLength - 1; i++){
            final->arr[k] = temp[i];
            k++;
        }
        final->length = longerLength - 1;
        free(temp);
    }
    else{
        final->arr = malloc(longerLength * sizeof(int));
        final->length = longerLength;
        final->arr = temp;
    }
    return final;
}